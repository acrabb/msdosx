//
//  BouncyModel.h
//  Bouncy
//
//  Created by Amir Khodaei on 9/24/12.
//  Copyright (c) 2012 Amir Khodaei. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BouncyModel : NSObject
{
    NSMutableArray* _balls;
    CGRect _bounds;
}

-(id)initWithBounds:(CGRect)rect;

@end
