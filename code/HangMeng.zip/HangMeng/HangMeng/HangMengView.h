//
//  HangMengView.h
//  HangMeng
//
//  Created by Amir Khodaei on 10/3/12.
//  Copyright (c) 2012 Crabb. All rights reserved.
//

#import <UIKit/UIKit.h>
@class HangMengViewController;

@interface HangMengView : UIView

@property (retain) IBOutlet HangMengViewController* myController;

@end
