//
//  HangMengTests.h
//  HangMengTests
//
//  Created by Amir Khodaei on 10/3/12.
//  Copyright (c) 2012 Crabb. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface HangMengTests : SenTestCase

@end
